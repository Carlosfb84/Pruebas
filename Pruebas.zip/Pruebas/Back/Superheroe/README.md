# Nombre del Proyecto: API de Superhéroes

## Descripción
Este proyecto es una API REST construida con Spring Boot para manejar un CRUD (Crear, Leer, Actualizar, Eliminar) de superhéroes. Permite consultar, añadir, modificar y eliminar superhéroes. 

## Tecnologías Utilizadas
- Spring Boot
- Spring Data JPA
- H2 Database
- Maven

## Cómo Ejecutar

### Requisitos Previos
- Java JDK 11 o superior
- Maven

### Pasos para Ejecutar
1. Clona el repositorio: `git clone [URL del Repositorio]`.
2. Navega al directorio del proyecto y ejecuta `mvn spring-boot:run`.
3. Accede a la aplicación a través de `http://localhost:8080/`.

## Endpoints de la API
- `GET /api/heroes`: Obtiene todos los superhéroes.
- `GET /api/heroes/{id}`: Obtiene un superhéroe por su ID.
- `POST /api/heroes`: Crea un nuevo superhéroe.
- `PUT /api/heroes/{id}`: Actualiza un superhéroe existente.
- `DELETE /api/heroes/{id}`: Elimina un superhéroe.

## Pruebas
Para ejecutar las pruebas, corre `mvn test`.

## Mejoras Futuras
- Implementar seguridad con JWT.
- Añadir caché de respuestas.
- Dockerizar la aplicación.
- Añadir documentación de API con Swagger.