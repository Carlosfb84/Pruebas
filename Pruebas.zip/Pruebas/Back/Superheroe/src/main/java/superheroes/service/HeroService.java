// HeroService.java
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.List;

@Service
public class HeroService {
    @Autowired
    private HeroRepository heroRepository;

    // Métodos para CRUD y búsqueda
}
