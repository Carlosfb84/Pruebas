import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Hero {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;

    // Aquí puedes agregar más atributos como 'power', 'origin', etc.

    // Constructor por defecto
    public Hero() {
    }

    // Constructor con parámetros
    public Hero(Long id, String name) {
        this.id = id;
        this.name = name;
        // Inicializar otros atributos si los hay
    }

    // Getters y setters para cada atributo
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    // Otros getters y setters si se agregan más atributos

    // Método toString para representar el objeto en forma de texto
    @Override
    public String toString() {
        return "Hero{" +
               "id=" + id +
               ", name='" + name + '\'' +
               '}';
    }
}

