import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public class HeroServiceTest {

    @Mock
    private HeroRepository heroRepository;

    @InjectMocks
    private HeroService heroService;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testGetAllHeroes() {
        // Configura tu mock de HeroRepository
        when(heroRepository.findAll()).thenReturn(Arrays.asList(new Hero(1L, "Superman")));

        // Llama al método que quieres probar
        List<Hero> result = heroService.findAll();

        // Verifica el resultado
        assertEquals(1, result.size());
        assertEquals("Superman", result.get(0).getName());
    }

    // Agrega más tests para otros métodos como findById, save, etc.
}
