nombre-proyecto/
├── src/
│   ├── main/
│   │   ├── java/
│   │   │   ├── tu/paquete/
│   │   │   │   ├── controller/
│   │   │   │   │   └── HeroController.java
│   │   │   │   ├── model/
│   │   │   │   │   └── Hero.java
│   │   │   │   ├── repository/
│   │   │   │   │   └── HeroRepository.java
│   │   │   │   └── service/
│   │   │   │       └── HeroService.java
│   │   ├── resources/
│   │   │   ├── application.properties
│   │   └── webapp/
│   ├── test/
│   │   ├── java/
│   │   │   ├── tu/paquete/
│   │   │   │   ├── controller/
│   │   │   │   │   └── HeroControllerTest.java
│   │   │   │   └── service/
│   │   │   │       └── HeroServiceTest.java
├── .gitignore
├── mvnw (o mvnw.cmd para Windows)
├── pom.xml
└── README.md
