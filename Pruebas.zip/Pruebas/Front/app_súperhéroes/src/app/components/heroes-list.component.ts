// heroes-list.component.ts
import { Component, OnInit } from '@angular/core';
import { SuperheroService } from './superhero.service';
import { Hero } from './hero.model';

@Component({
  selector: 'app-heroes-list',
  templateUrl: './heroes-list.component.html'
})
export class HeroesListComponent implements OnInit {
  heroes: Hero[] = [];

  constructor(private superheroService: SuperheroService) {}

  ngOnInit() {
    this.superheroService.getHeroes().subscribe(heroes => {
      this.heroes = heroes;
    });
  }

  // Métodos para añadir, editar, y borrar héroes