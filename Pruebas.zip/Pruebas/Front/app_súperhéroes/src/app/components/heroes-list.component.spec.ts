// src/app/heroes-list/heroes-list.component.spec.ts
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HeroesListComponent } from './heroes-list.component';
import { SuperheroService } from '../services/superhero.service';
import { of } from 'rxjs';

describe('HeroesListComponent', () => {
  let component: HeroesListComponent;
  let fixture: ComponentFixture<HeroesListComponent>;
  let service: SuperheroService;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HeroesListComponent ],
      providers: [ SuperheroService ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HeroesListComponent);
    component = fixture.componentInstance;
    service = TestBed.inject(SuperheroService);

    spyOn(service, 'getHeroes').and.returnValue(of([
      { id: 1, name: 'Spiderman' },
      { id: 2, name: 'Superman' }
    ]));

    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call service to get heroes', () => {
    expect(service.getHeroes).toHaveBeenCalled();
    expect(component.heroes.length).toBe(2);
  });

  // Agrega más pruebas para comprobar la interacción con el servicio y la UI
});
