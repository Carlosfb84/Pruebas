/ hero-form.component.ts
import { Component, Input } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { SuperheroService } from './superhero.service';
import { Hero } from './hero.model';

@Component({
  selector: 'app-hero-form',
  templateUrl: './hero-form.component.html'
})
export class HeroFormComponent {
  @Input() hero: Hero | null = null;

  heroForm = new FormGroup({
    name: new FormControl(''),
    // Otros campos
  });

  constructor(private superheroService: SuperheroService) {}

  onSubmit() {
    // Lógica para enviar el formulario
  }
}