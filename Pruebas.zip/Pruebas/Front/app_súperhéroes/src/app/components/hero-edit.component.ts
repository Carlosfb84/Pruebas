import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-hero-edit',
  template: `
    <form [formGroup]="heroForm" (ngSubmit)="onSubmit()">
      <div>
        <label for="name">Nombre:</label>
        <input type="text" id="name" formControlName="name">
        <div *ngIf="heroForm.get('name')?.invalid && (heroForm.get('name')?.dirty || heroForm.get('name')?.touched)">
          <small *ngIf="heroForm.get('name')?.errors?.['required']">El nombre es requerido.</small>
          <small *ngIf="heroForm.get('name')?.errors?.['minlength']">El nombre debe tener al menos 3 caracteres.</small>
        </div>
      </div>

      <div>
        <label for="power">Poder especial:</label>
        <input type="text" id="power" formControlName="power">
        <div *ngIf="heroForm.get('power')?.invalid && (heroForm.get('power')?.dirty || heroForm.get('power')?.touched)">
          <small *ngIf="heroForm.get('power')?.errors?.['required']">El poder especial es requerido.</small>
        </div>
      </div>

      <div>
        <label for="strength">Fortaleza (1-100):</label>
        <input type="number" id="strength" formControlName="strength">
        <div *ngIf="heroForm.get('strength')?.invalid && (heroForm.get('strength')?.dirty || heroForm.get('strength')?.touched)">
          <small *ngIf="heroForm.get('strength')?.errors?.['required']">La fortaleza es requerida.</small>
          <small *ngIf="heroForm.get('strength')?.errors?.['min'] || heroForm.get('strength')?.errors?.['max']">La fortaleza debe estar entre 1 y 100.</small>
        </div>
      </div>

      <button type="submit" [disabled]="!heroForm.valid">Guardar Superhéroe</button>
    </form>
  `,
  styles: []
})
export class HeroEditComponent implements OnInit {
  heroForm: FormGroup;

  constructor(private fb: FormBuilder) { }

  ngOnInit() {
    this.heroForm = this.fb.group({
      name: ['', [Validators.required, Validators.minLength(3)]],
      power: ['', Validators.required],
      strength: ['', [Validators.required, Validators.min(1), Validators.max(100)]]
    });
  }

  onSubmit() {
    if (this.heroForm.valid) {
      console.log('Formulario de Superhéroe:', this.heroForm.value);
      // Aquí se manejaría la lógica para agregar o actualizar al superhéroe
    }
  }
}
