// hero.model.ts
export interface Hero {
  id: number;
  name: string;
  // Otros atributos relevantes
}