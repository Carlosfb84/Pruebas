// superhero.service.ts
import { Injectable } from '@angular/core';
import { Hero } from './hero.model';
import { BehaviorSubject, Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})

export class SuperheroService {
  private heroesSubject = new BehaviorSubject<Hero[]>([]);
  heroes$ = this.heroesSubject.asObservable();

 
    private apiUrl = 'http://localhost:3000/heroes';
  
    constructor(private http: HttpClient) {}
  
    getHeroes() {
      return this.http.get<Hero[]>(this.apiUrl);
    }
  
    // otros métodos...
  }

  private heroes: Hero[] = [
    // Datos iniciales
  ];

  constructor() {
    this.heroesSubject.next(this.heroes);
  }

  getHeroes(): Observable<Hero[]> {
    return this.heroes$;
  }

  getHeroById(id: number): Hero | undefined {
    return this.heroes.find(hero => hero.id === id);
  }

  searchHeroes(query: string): Hero[] {
    return this.heroes.filter(hero => hero.name.toLowerCase().includes(query.toLowerCase()));
  }

  addHero(hero: Hero): void {
    this.heroes.push(hero);
    this.heroesSubject.next(this.heroes);
  }

  updateHero(updatedHero: Hero): void {
    const index = this.heroes.findIndex(hero => hero.id === updatedHero.id);
    if (index > -1) {
      this.heroes[index] = updatedHero;
      this.heroesSubject.next(this.heroes);
    }
  }

  deleteHero(id: number): void {
    this.heroes = this.heroes.filter(hero => hero.id !== id);
    this.heroesSubject.next(this.heroes);
  }
}