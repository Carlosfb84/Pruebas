// src/app/services/superhero.service.spec.ts
import { TestBed } from '@angular/core/testing';
import { SuperheroService } from './superhero.service';
import { Hero } from '../models/hero.model';

describe('SuperheroService', () => {
  let service: SuperheroService;
  let heroList: Hero[];

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SuperheroService);
    heroList = [
      { id: 1, name: 'Spiderman' },
      { id: 2, name: 'Superman' }
    ];
    service['heroes'] = heroList;
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should return all heroes', () => {
    service.getHeroes().subscribe(heroes => {
      expect(heroes.length).toBe(2);
      expect(heroes).toEqual(heroList);
    });
  });

  // Agrega más pruebas para otros métodos como addHero, deleteHero, etc.
});
